"""
SLS_player for Android (Kivy)
Also runs on desktop for testing:  pip install kivy mutagen && python main.py
"""
import os
import random

from kivy.app import App
from kivy.clock import Clock
from kivy.core.audio import SoundLoader
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.checkbox import CheckBox
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.slider import Slider
from kivy.utils import platform

SUPPORTED = (".mp3", ".wav", ".ogg", ".flac", ".m4a")


def fmt(sec):
    sec = max(0, int(sec))
    return f"{sec // 60:02d}:{sec % 60:02d}"


class SeekSlider(Slider):
    """Slider that reports when the user lets go, so we can seek."""
    def __init__(self, on_release=None, **kw):
        super().__init__(**kw)
        self.on_release = on_release
        self.dragging = False

    def on_touch_down(self, touch):
        if self.collide_point(*touch.pos):
            self.dragging = True
        return super().on_touch_down(touch)

    def on_touch_up(self, touch):
        was = self.dragging
        self.dragging = False
        res = super().on_touch_up(touch)
        if was and self.on_release:
            self.on_release(self.value)
        return res


class PlayerUI(BoxLayout):
    def __init__(self, **kw):
        super().__init__(orientation="vertical", padding=dp(10), spacing=dp(8), **kw)
        self.tracks = []
        self.current = -1
        self.sound = None
        self.playing = False
        self.paused = False
        self.pause_pos = 0.0
        self.rows = []

        self.title_lbl = Label(text="No track loaded", size_hint_y=None,
                               height=dp(48), halign="center", valign="middle",
                               bold=True, font_size="16sp")
        self.title_lbl.bind(size=lambda w, s: setattr(w, "text_size", s))
        self.add_widget(self.title_lbl)

        # progress
        prog = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(6))
        self.pos_lbl = Label(text="00:00", size_hint_x=None, width=dp(48))
        self.seek = SeekSlider(on_release=self.on_seek, min=0, max=100, value=0)
        self.len_lbl = Label(text="--:--", size_hint_x=None, width=dp(48))
        prog.add_widget(self.pos_lbl)
        prog.add_widget(self.seek)
        prog.add_widget(self.len_lbl)
        self.add_widget(prog)

        # controls
        ctrl = BoxLayout(size_hint_y=None, height=dp(56), spacing=dp(8))
        ctrl.add_widget(Button(text="Prev", on_release=lambda *_: self.prev_track()))
        self.play_btn = Button(text="Play", on_release=lambda *_: self.toggle_play())
        ctrl.add_widget(self.play_btn)
        ctrl.add_widget(Button(text="Stop", on_release=lambda *_: self.stop()))
        ctrl.add_widget(Button(text="Next", on_release=lambda *_: self.next_track()))
        self.add_widget(ctrl)

        # options
        opts = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(4))
        self.shuffle = CheckBox(size_hint_x=None, width=dp(36))
        self.repeat = CheckBox(size_hint_x=None, width=dp(36))
        opts.add_widget(self.shuffle)
        opts.add_widget(Label(text="Shuffle", size_hint_x=None, width=dp(64)))
        opts.add_widget(self.repeat)
        opts.add_widget(Label(text="Repeat", size_hint_x=None, width=dp(60)))
        self.vol = Slider(min=0, max=1, value=0.7)
        self.vol.bind(value=self.on_volume)
        opts.add_widget(Label(text="Vol", size_hint_x=None, width=dp(32)))
        opts.add_widget(self.vol)
        self.add_widget(opts)

        # playlist
        self.grid = GridLayout(cols=1, size_hint_y=None, spacing=dp(2))
        self.grid.bind(minimum_height=self.grid.setter("height"))
        sv = ScrollView()
        sv.add_widget(self.grid)
        self.add_widget(sv)

        self.add_widget(Button(text="Scan for music", size_hint_y=None,
                               height=dp(48),
                               on_release=lambda *_: self.scan()))

        Clock.schedule_interval(self.tick, 0.5)
        Clock.schedule_once(lambda dt: self.start_up(), 0.3)

    # ---------- startup / library ----------
    def start_up(self):
        if platform == "android":
            from android.permissions import request_permissions
            request_permissions(
                ["android.permission.READ_MEDIA_AUDIO",
                 "android.permission.READ_EXTERNAL_STORAGE"],
                lambda perms, results: self.scan(),
            )
        else:
            self.scan()

    def music_dirs(self):
        if platform == "android":
            root = "/storage/emulated/0"
            return [f"{root}/Music", f"{root}/Download", f"{root}/Downloads"]
        return [os.path.expanduser("~/Music")]

    def scan(self):
        found = []
        for d in self.music_dirs():
            if not os.path.isdir(d):
                continue
            for base, _, files in os.walk(d):
                for f in sorted(files):
                    if f.lower().endswith(SUPPORTED):
                        found.append(os.path.join(base, f))
        self.tracks = found
        self.grid.clear_widgets()
        self.rows = []
        for i, p in enumerate(found):
            b = Button(text=os.path.basename(p), size_hint_y=None, height=dp(44),
                       halign="left", valign="middle",
                       background_color=(0.2, 0.2, 0.25, 1))
            b.bind(size=lambda w, s: setattr(w, "text_size", (s[0] - dp(16), s[1])))
            b.bind(on_release=lambda w, idx=i: self.play_index(idx))
            self.grid.add_widget(b)
            self.rows.append(b)
        if not found:
            self.title_lbl.text = "No music found in Music/Download folders"
        else:
            self.title_lbl.text = f"{len(found)} tracks found"

    # ---------- playback ----------
    def play_index(self, idx, start=0.0):
        if not (0 <= idx < len(self.tracks)):
            return
        self._unload()
        snd = SoundLoader.load(self.tracks[idx])
        if snd is None:
            self.title_lbl.text = "Can't play: " + os.path.basename(self.tracks[idx])
            return
        self.sound = snd
        snd.volume = self.vol.value
        snd.play()
        if start > 0:
            snd.seek(start)
        self.current = idx
        self.playing = True
        self.paused = False
        self.play_btn.text = "Pause"
        self.title_lbl.text = os.path.basename(self.tracks[idx])
        length = snd.length or 0
        self.seek.max = length if length > 0 else 100
        self.len_lbl.text = fmt(length) if length > 0 else "--:--"
        for i, b in enumerate(self.rows):
            b.background_color = (0.1, 0.5, 0.8, 1) if i == idx else (0.2, 0.2, 0.25, 1)

    def _unload(self):
        if self.sound:
            try:
                self.sound.stop()
                self.sound.unload()
            except Exception:
                pass
            self.sound = None

    def toggle_play(self):
        if not self.tracks:
            self.scan()
            return
        if not self.playing:
            self.play_index(max(self.current, 0))
        elif self.paused:
            self.sound.play()
            self.sound.seek(self.pause_pos)
            self.paused = False
            self.play_btn.text = "Pause"
        else:
            self.pause_pos = self.sound.get_pos()
            self.sound.stop()
            self.paused = True
            self.play_btn.text = "Play"

    def stop(self):
        self._unload()
        self.playing = False
        self.paused = False
        self.play_btn.text = "Play"
        self.seek.value = 0
        self.pos_lbl.text = "00:00"

    def next_track(self):
        if not self.tracks:
            return
        if self.shuffle.active and len(self.tracks) > 1:
            self.play_index(random.choice(
                [i for i in range(len(self.tracks)) if i != self.current]))
        else:
            self.play_index((self.current + 1) % len(self.tracks))

    def prev_track(self):
        if not self.tracks:
            return
        pos = self.pause_pos if self.paused else (self.sound.get_pos() if self.sound else 0)
        if pos > 3:
            self.play_index(self.current)
        else:
            self.play_index((self.current - 1) % len(self.tracks))

    def on_seek(self, value):
        if self.sound and self.playing:
            if self.paused:
                self.pause_pos = value
            else:
                self.sound.seek(value)

    def on_volume(self, _w, value):
        if self.sound:
            self.sound.volume = value

    def tick(self, _dt):
        if not self.playing or self.sound is None:
            return
        if self.paused:
            return
        if self.sound.state == "play":
            pos = self.sound.get_pos()
            self.pos_lbl.text = fmt(pos)
            if not self.seek.dragging:
                self.seek.value = min(pos, self.seek.max)
        else:
            # track ended
            if self.repeat.active:
                self.play_index(self.current)
            elif self.current < len(self.tracks) - 1 or self.shuffle.active:
                self.next_track()
            else:
                self.stop()


class MusicApp(App):
    title = "SLS_player"

    def build(self):
        Window.clearcolor = (0.08, 0.08, 0.1, 1)
        return PlayerUI()

    def on_pause(self):
        return True  # keep app alive when backgrounded


if __name__ == "__main__":
    MusicApp().run()
